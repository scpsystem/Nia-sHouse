"""
Menyediakan aset daripada OBJECT.zip -> public/assets/ (WebP, nama mudah).
Guna: python3 tools/prepare_assets.py "<folder '3D OBJECT'>" public/assets
Keperluan: pillow, numpy, scipy, opencv-python-headless
"""
import sys, os
import numpy as np, cv2
from PIL import Image
from scipy import ndimage as ndi

SRC = sys.argv[1] if len(sys.argv) > 1 else "3D OBJECT"
OUT = sys.argv[2] if len(sys.argv) > 2 else "public/assets"
for d in ("bg", "nia", "items"):
    os.makedirs(os.path.join(OUT, d), exist_ok=True)

def p(*a): return os.path.join(SRC, *a)
def o(*a): return os.path.join(OUT, *a)

def cutout(path, bg, tol):
    """Buang latar pepejal (hitam/putih) yang bersambung ke tepi imej."""
    a = np.array(Image.open(path).convert("RGBA")).astype(int)
    d = np.abs(a[..., :3] - np.array(bg)).max(axis=2)
    lab, _ = ndi.label(d <= tol)
    edge = set(np.unique(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]]))) - {0}
    mask = np.isin(lab, list(edge))
    alpha = np.where(mask, 0, 255).astype(np.uint8)
    alpha = cv2.GaussianBlur(alpha, (3, 3), 0)
    er = cv2.erode((alpha > 128).astype(np.uint8) * 255, np.ones((3, 3), np.uint8))
    alpha = np.minimum(alpha, cv2.GaussianBlur(er, (3, 3), 0))
    a[..., 3] = alpha
    return Image.fromarray(a.astype(np.uint8))

def trim(im):
    bb = im.getchannel("A").point(lambda v: 255 if v > 8 else 0).getbbox()
    return im.crop(bb)

def save_bg(src, name, size=(1600, 900)):
    im = Image.open(src).convert("RGBA")
    base = Image.new("RGBA", im.size, (255, 255, 255, 255))
    base.alpha_composite(im)
    im = base.convert("RGB").resize(size, Image.LANCZOS)
    im.save(o("bg", name + ".webp"), quality=84, method=6)

def save_rgba(im, path, max_h=None, max_w=None):
    if max_h and im.height > max_h:
        im = im.resize((round(im.width * max_h / im.height), max_h), Image.LANCZOS)
    if max_w and im.width > max_w:
        im = im.resize((max_w, round(im.height * max_w / im.width)), Image.LANCZOS)
    im.save(path, quality=88, method=6)

# ---------- Latar ----------
save_bg(p("bilik", "bilik bersepah.png"), "bilik-bersepah")
save_bg(p("bilik", "bilik pandangan hadapan.png"), "bilik-kemas")
save_bg(p("bilik", "almari pakaian.png"), "almari")
save_bg(p("bilik air", "bilik air.png"), "bilik-air")
save_bg(p("bilik air", "sinki.png"), "sinki")
save_bg(p("dapur", "dapur pandangan hadapan.png"), "dapur-depan")
save_bg(p("dapur", "dapur pandangan atas.png"), "dapur-atas")
save_bg(p("dapur", "atas meja.png"), "atas-meja")
save_bg(p("luar rumah", "halaman.png"), "halaman")
save_bg(p("ruang tamu", "ruang bersepah.png"), "ruang-bersepah")
save_bg(p("ruang tamu", "ruang kemas.png"), "ruang-kemas")
save_bg(p("dapur", "notaIbu.png"), "nota-ibu", (1200, 800))
save_bg(p("bilik", "ruang belajar.png"), "ruang-belajar", (1200, 800))

# ---------- Nia: berdiri (tiga pakaian, kaki sejajar, skala sama) ----------
stand = {
    "asal": Image.open(p("watak", "watak asal.png")).convert("RGBA"),
    "pink": cutout(p("watak", "watak baju pink.png"), (0, 0, 0), 14),
    "tidur": Image.open(p("watak", "watak baju tidur.png")).convert("RGBA"),
}
trimmed = {k: trim(v) for k, v in stand.items()}
W = max(t.width for t in trimmed.values()) + 20
H = max(t.height for t in trimmed.values())
SCALE = 760 / H
meta = {}
for k, t in trimmed.items():
    canvas = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    canvas.alpha_composite(t, ((W - t.width) // 2, H - t.height))
    canvas = canvas.resize((round(W * SCALE), round(H * SCALE)), Image.LANCZOS)
    canvas.save(o("nia", f"stand-{k}.webp"), quality=90, method=6)
    meta[k] = canvas.size
print("stand canvas", meta)

# ---------- Nia: tidur, duduk, gosok gigi, muka ----------
save_rgba(trim(Image.open(p("watak", "watak tidur.png")).convert("RGBA")), o("nia", "sleep.webp"), max_w=900)
save_rgba(trim(cutout(p("watak", "duduk.png"), (0, 0, 0), 14)), o("nia", "sit.webp"), max_h=760)
save_rgba(trim(cutout(p("watak", "duduk pandangan atas.png"), (255, 255, 255), 10)), o("nia", "sit-top.webp"), max_h=760)
im = Image.open(p("watak", "gosok gigi.png")).convert("RGBA")
im = im.resize((round(im.width * 1000 / im.height), 1000), Image.LANCZOS)
im.save(o("nia", "brush-closeup.webp"), quality=88, method=6)

asal = trimmed["asal"]
face = asal.crop((0, 0, asal.width, int(asal.height * 0.30)))
side = max(face.size)
sq = Image.new("RGBA", (side, side), (0, 0, 0, 0)); sq.alpha_composite(face, ((side - face.width) // 2, 0))
save_rgba(sq, o("nia", "face.webp"), max_h=300)

# ---------- Objek ----------
save_rgba(trim(Image.open(p("bilik", "baju cantik.png")).convert("RGBA")), o("items", "baju-cantik.webp"), max_h=500)
save_rgba(trim(Image.open(p("bilik", "baju tidur.png")).convert("RGBA")), o("items", "baju-tidur.webp"), max_h=500)
save_rgba(trim(Image.open(p("bilik", "baju.png")).convert("RGBA")), o("items", "baju-lain.webp"), max_h=500)
save_rgba(trim(Image.open(p("ruang tamu", "bakul baju kotor.png")).convert("RGBA")), o("items", "bakul-baju-kotor.webp"), max_h=500)
save_rgba(trim(cutout(p("bilik", "sikat.jpg"), (255, 255, 255), 12)), o("items", "sikat.webp"), max_h=300)
# T-shirt ungu: potong bahagian badan daripada Nia asal
ts = asal.crop((int(asal.width * 0.12), int(asal.height * 0.305), int(asal.width * 0.88), int(asal.height * 0.56)))
save_rgba(trim(ts), o("items", "tshirt-ungu.webp"), max_h=420)
print("siap")
